/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define HEART_BEAT_Pin GPIO_PIN_13
#define HEART_BEAT_GPIO_Port GPIOC
#define INT_SPI1_Pin GPIO_PIN_0
#define INT_SPI1_GPIO_Port GPIOA
#define INT_SPI1_EXTI_IRQn EXTI0_IRQn
#define INT_SPI2_Pin GPIO_PIN_1
#define INT_SPI2_GPIO_Port GPIOA
#define INT_SPI2_EXTI_IRQn EXTI1_IRQn
#define RST_SPI1_Pin GPIO_PIN_2
#define RST_SPI1_GPIO_Port GPIOA
#define RST_SPI2_Pin GPIO_PIN_3
#define RST_SPI2_GPIO_Port GPIOA
#define NSS_SPI1_Pin GPIO_PIN_4
#define NSS_SPI1_GPIO_Port GPIOA
#define NSS_SPI2_Pin GPIO_PIN_12
#define NSS_SPI2_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
